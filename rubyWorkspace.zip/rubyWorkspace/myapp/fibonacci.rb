class Fibonacci
  def series
    puts "Enter the Fibonacci value"
    n=gets.to_i
    f1=0
    f2=1
    f3=0
    puts f1,f2
    for i in 2...n
      f3=f1+f2
      puts f3
      f1=f2
      f2=f3
      i=i+1  
    end
  end
end

obj=Fibonacci.new
obj.series