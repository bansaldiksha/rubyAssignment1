class TwoParameters
  def sumConcatenate
    puts "Enter two parameters"
    a = gets.strip
    b = gets.strip

    c = a.ord
    d = b.ord

    if c>47 && c<58 && d>47 && d<58
      a = a.to_i
      b = b.to_i
      puts "The sum is #{a+b}"
    elsif c>64 && c<123 && d>64 && d<123
      puts "The concatenated string is " + a + b
    else
      puts "There is type error"
    end
    
  end
end

obj=TwoParameters.new
obj.sumConcatenate